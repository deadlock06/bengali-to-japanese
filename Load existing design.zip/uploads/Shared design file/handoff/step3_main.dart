// Bhasago — app entry point (v4 "Bold Ink" shell). Step 3 of the design handoff.
//
// Changes vs v0.1 main.dart:
//  - 4-tab NavigationBar: Home / Learn / Speak / Progress (was 6 flat tabs)
//  - HomeScreen (step 2) is tab 0; Kana, Writing, Pitch, Review are reached
//    by push from Home cards / the Learn tab — not top-level tabs
//  - AppBar removed on Home (design has its own greeting header); kept on
//    pushed pages for back navigation
//  - Locale + theme wiring unchanged (localeProvider, BhasagoTheme.dark())
//
// Wiring: replace lib/main.dart with this AFTER steps 1-2 are in place.
// AiCheckScreen (step 5) is stubbed behind a TODO so this compiles today.

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'l10n/app_localizations.dart';
import 'app/providers.dart';
import 'app/theme.dart';
import 'presentation/home_screen.dart';
import 'presentation/screens.dart';
import 'presentation/accent_screens.dart';
import 'presentation/lesson_list_screen.dart';
import 'presentation/progress_screen.dart';
import 'presentation/settings_screen.dart';
import 'presentation/writing_screen.dart';

void main() => runApp(const ProviderScope(child: SenseiApp()));

class SenseiApp extends ConsumerWidget {
  const SenseiApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);
    return MaterialApp(
      title: 'Bhasago',
      debugShowCheckedModeBanner: false,
      locale: locale,
      supportedLocales: const [Locale('en'), Locale('bn'), Locale('ja')],
      localizationsDelegates: const [
        S.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: BhasagoTheme.dark(),
      home: const HomeShell(),
      // TODO(step 4): first-run language-select onboarding gate here —
      // if !prefs.localeChosen → OnboardingScreen() else HomeShell().
    );
  }
}

class HomeShell extends ConsumerStatefulWidget {
  const HomeShell({super.key});
  @override
  ConsumerState<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends ConsumerState<HomeShell> {
  int tab = 0;

  void _push(BuildContext context, String title, Widget body) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: body,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);

    // Tab bodies. Home gets callbacks so it never touches Navigator directly.
    final pages = <Widget>[
      HomeScreen(
        onOpenLesson: () => setState(() => tab = 1),
        onOpenReview: () =>
            _push(context, s.navReview, const ReviewScreen()),
        onOpenAiCheck: () =>
            // TODO(step 5): replace with AiCheckScreen()
            _push(context, 'AI চেক', const ProgressScreen()),
        onOpenProgress: () => setState(() => tab = 3),
      ),
      const LessonListScreen(),
      const ShadowingScreen(),
      const ProgressScreen(),
    ];

    return Scaffold(
      // Design: Home has its own header; other tabs keep a slim AppBar.
      appBar: tab == 0
          ? AppBar(
              title: const Text('Bhasago'),
              actions: [
                // Kana grid + writing practice moved off the tab bar (v4):
                IconButton(
                  icon: const Icon(Icons.grid_view),
                  tooltip: s.kanaTitle,
                  onPressed: () =>
                      _push(context, s.kanaTitle, const KanaScreen()),
                ),
                IconButton(
                  icon: const Icon(Icons.draw),
                  tooltip: 'লিখো · Write',
                  onPressed: () =>
                      _push(context, 'লিখো · Write', const WritingScreen()),
                ),
                IconButton(
                  icon: const Icon(Icons.settings_outlined),
                  tooltip: 'সেটিংস · Settings',
                  onPressed: () => _push(
                      context, 'সেটিংস · Settings', const SettingsScreen()),
                ),
              ],
            )
          : null,
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), label: 'হোম'),
          NavigationDestination(icon: const Icon(Icons.school_outlined), label: s.navLearn),
          NavigationDestination(icon: const Icon(Icons.mic_none), label: s.navSpeak),
          const NavigationDestination(
              icon: Icon(Icons.monitor_heart_outlined), label: 'অগ্রগতি'),
        ],
      ),
    );
  }
}
