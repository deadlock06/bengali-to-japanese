# Bhasago v4 "Bold Ink" design handoff

Updated 2026-07-11 (rev 2) — step 6 revised: AI Classroom is now the flagship
blood-red section; adds sensei chat/talk sheet, language persistence,
full l10n of Learn + lesson strings, compacted lesson UI. Previous rev added step 6
(blended into the Home v4 shell; design source `Home v4.dc.html` lesson tab,
state reference `AI Classroom.dc.html`).

Generated 2026-07-10 from the approved design `Home v4.dc.html` (this design
project). Five ordered steps; each file header carries its own wiring notes.
Apply in order — later steps import earlier ones.

## Design summary
- **Palette**: ink-black surfaces (`#0F0F0F` / `#1A1A1A` / outline `#2E2E2E`) +
  four solid accent inks: yellow `#EFE94B` (current lesson / primary), pink
  `#F06EB7` (review), blue `#4D7DF7` (AI exam), green `#35E065` (progress).
  Content on accent fills is always near-black `#111`.
- **Shape**: cards 20px radius, all buttons/chips stadium pills, bottom-nav
  active item = white pill with icon+label.
- **Type**: Baloo Da 2 (Bengali + display), Zen Kaku Gothic New (Japanese),
  Archivo (Latin labels), Space Grotesk optional for numbers.
- **IA change**: 4-tab shell (Home / Learn / Speak / Progress). Kana, Writing,
  Pitch, Review are pushed pages, not tabs. First run = language-select
  onboarding. Progress tab hosts the live retention chart; AI-check screen
  runs the mock exam and gives Banglish suggestions.

## Files → destinations
| Handoff file | Repo destination | Notes |
|---|---|---|
| `step1_theme.dart` | `lib/app/theme.dart` (replace) | Same public API; `ai`/`sakura`/`gold` tokens removed — grep for usages first. Add fonts to `pubspec.yaml`. |
| `step2_home_screen.dart` | `lib/presentation/home_screen.dart` (new) | Riverpod; nav via callbacks; TODOs mark real-data hookups (`dueCount`, course %, topics). |
| `step3_main.dart` | `lib/main.dart` (replace) | 4-tab shell. PitchScreen needs a new entry point (TODO). AiCheck stubbed until step 5. |
| `step4_onboarding_screen.dart` | `lib/presentation/onboarding_screen.dart` (new) | Needs `shared_preferences` in pubspec + `localeChosenProvider` snippet (in file header) added to `app/providers.dart`. |
| `step5_progress_ai_check.dart` | `lib/presentation/progress_screen_v4.dart` (new) | `retentionSeriesProvider` demo-backed until T-108 query exists. Mock exam grades vs answer key ONLY (00 non-negotiable). `withValues` needs Flutter 3.27+; else use `withOpacity`. |
| `step6_lesson_screen.dart` | `lib/presentation/lesson_screen_v4.dart` (new) | Adaptive lesson: 5 moods (neutral/flow/struggle/burnout/boredom) tint one classroom scene. Wire Home AI-Classroom card `goLesson` → push. Demo word batch until T-112 SRS query. See rev-2 delta notes below. |

## Rev-2 deltas (2026-07-11) — apply on top of step files
1. **AI Classroom card (home_screen)**: the yellow "current lesson" card is now
   the flagship **AI Classroom** entry. Blood red `#B3121B` fill (new token
   `aiClassroomRed` — EXCLUSIVE to this section, do not reuse elsewhere),
   `#F5F5F0` star + title, subtitle `#F5B8BC`, progress fill `#F5F5F0` with
   knob `#B3121B`/border `#111`. Motion: hover/press = slight 3D tilt +
   red glow shadow (28% alpha), scale .98 on press, progress width eases
   .6s cubic-bezier(.2,.8,.2,1). Title l10n key `aiClassroom`:
   bn 'AI ক্লাসরুম' / en 'AI Classroom' / ja 'AI教室'. This section will grow
   more pages; treat red as its section ink.
2. **Locale persistence**: language choice saved (shared_preferences key
   `bhasago.lang`), read on boot; skip onboarding when present. Language pill
   cycle must also update pending selection (bug fixed in design).
3. **Full l10n**: Learn-tab + lesson strings moved to keys (learnBadge,
   showAns, skipBtn, hintBtn, closeBtn, meanHidden, lessonTitle, whatMean,
   lessonDone*, practiceAgain, backHome, aiClassroom, senseiName, askLabel,
   chatPh, listenLabel). Lesson answer OPTIONS + hints + mood labels/messages
   are localized bn/en(/ja fallback en) — add to arb files.
4. **Sensei chat/talk sheet (new, inside lesson)**: tapping the teacher opens
   a bottom sheet (76% height, 24px top radius, `#141414` on `#2E2E2E`
   border): header = 先 avatar in mood-color ring + name + live mood dot;
   reversed-column message list (student bubble = mood accent bg + #111 text,
   radius 16/16/4/16; sensei bubble = #1A1A1A + #2E2E2E border, 16/16/16/4);
   typing indicator (3 pulsing dots); quick chips (Explain again / Example /
   Pronunciation); input row = stadium text field + mood-color send FAB (44px)
   + mic button. Mic = voice mode: 5-bar waveform in mood color + "Listening…"
   then transcribe→send. DESIGN IS DEMO-CANNED: production wires to the AI
   tutor service; grading stays answer-key only (chat is explanatory, D-001).
5. **Lesson UI scale (compact)**: kanji 42, options/toolbar pills 44px min,
   progress bar 4px, teacher sprite 52×64, question card padding 14/14/12.

## Adaptive lesson (step 6) — mood model
- One classroom scene, five states; ONE accent dominates per state:
  neutral `#EFE94B` · flow `#35E065` · struggle `#F0954B` (new token) ·
  burnout `#4D7DF7` · boredom `#A78BF7` (new token).
- Transitions: correct → flow; 3-streak → boredom (offer harder items);
  wrong → struggle + auto-open hint; 3 wrongs → burnout (suggest break);
  skip resets to neutral. All state shifts are ambient (color/copy) — never
  blocking, never shaming (D-001).
- Motion: lanternSway 6s ease-in-out ±2°, dust motes rise 7–9s linear,
  progress-fill shimmer 2.6s, card entrance 0.5s cubic-bezier(.2,.8,.2,1).
  Burnout state is intentionally STILL. Respect `disableAnimations`.

## Spec compliance checked
- D-001: no streak warnings/saves, no locks, neutral fail states.
- Skip/Hint/Quit invariant: step 6 keeps all three always-available (ইঙ্গিত/বাদ/বন্ধ pills, fixed toolbar).
- Correctness model: AI examiner = answer-key grading; LLM phrases feedback only.
- Secure storage stays DB-key-only; locale in shared_preferences.

## After copying, run
```
flutter pub get
flutter gen-l10n
flutter analyze
flutter test
```

## Open follow-ups (not in this handoff)
1. l10n: new strings are hardcoded BN for design parity — move to
   `lib/l10n/app_{en,bn,ja}.arb` (add navHome/navProgress/home* keys).
2. PitchScreen entry point (card inside Speak tab).
3. T-108: real `retentionByDay()` + per-skill accuracy queries in `srs_local.dart`.
4. dueCountProvider reading `SrsLocal.dueCards()` for the pink card.
5. T-112: `SrsLocal.nextLessonBatch()` to replace step 6 demo word list.
6. Step 6 ambiance animation loops (lantern/dust) — painter is static in
   handoff; add AnimationController wrapper per file comments.

## Suggested commit message
```
design: v4 "Bold Ink" UI refresh + adaptive AI Classroom lesson

- new token set: ink-black surfaces + yellow/pink/blue/green accent inks
- 4-tab shell (Home/Learn/Speak/Progress); Kana/Write/Pitch/Review as pushes
- new HomeScreen, OnboardingScreen (language-first), ProgressScreenV4 + AiCheckScreen
- fonts: Baloo Da 2 / Zen Kaku Gothic New / Archivo
- new LessonScreenV4: 5-mood adaptive classroom (flow/struggle/burnout/boredom)
- spec-checked: D-001 neutral framing, answer-key grading, Skip/Hint/Quit intact

Design source: Home v4.dc.html (Claude design project)
```
