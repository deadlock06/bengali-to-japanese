# Bhasago v4 "Bold Ink" design handoff

Generated 2026-07-10 from the approved design `Home v4.dc.html` (this design
project). Five ordered steps; each file header carries its own wiring notes.
Apply in order — later steps import earlier ones.

## Design summary
- **Palette**: ink-black surfaces (`#0F0F0F` / `#1A1A1A` / outline `#2E2E2E`) +
  four solid accent inks: yellow `#EFE94B` (current lesson / primary), pink
  `#F06EB7` (review), blue `#4D7DF7` (AI exam), green `#35E065` (progress).
  Content on accent fills is always near-black `#111`.
- **Shape**: cards 20px radius, all buttons/chips stadium pills, bottom-nav
  active item = white pill with icon+label.
- **Type**: Baloo Da 2 (Bengali + display), Zen Kaku Gothic New (Japanese),
  Archivo (Latin labels), Space Grotesk optional for numbers.
- **IA change**: 4-tab shell (Home / Learn / Speak / Progress). Kana, Writing,
  Pitch, Review are pushed pages, not tabs. First run = language-select
  onboarding. Progress tab hosts the live retention chart; AI-check screen
  runs the mock exam and gives Banglish suggestions.

## Files → destinations
| Handoff file | Repo destination | Notes |
|---|---|---|
| `step1_theme.dart` | `lib/app/theme.dart` (replace) | Same public API; `ai`/`sakura`/`gold` tokens removed — grep for usages first. Add fonts to `pubspec.yaml`. |
| `step2_home_screen.dart` | `lib/presentation/home_screen.dart` (new) | Riverpod; nav via callbacks; TODOs mark real-data hookups (`dueCount`, course %, topics). |
| `step3_main.dart` | `lib/main.dart` (replace) | 4-tab shell. PitchScreen needs a new entry point (TODO). AiCheck stubbed until step 5. |
| `step4_onboarding_screen.dart` | `lib/presentation/onboarding_screen.dart` (new) | Needs `shared_preferences` in pubspec + `localeChosenProvider` snippet (in file header) added to `app/providers.dart`. |
| `step5_progress_ai_check.dart` | `lib/presentation/progress_screen_v4.dart` (new) | `retentionSeriesProvider` demo-backed until T-108 query exists. Mock exam grades vs answer key ONLY (00 non-negotiable). `withValues` needs Flutter 3.27+; else use `withOpacity`. |

## Spec compliance checked
- D-001: no streak warnings/saves, no locks, neutral fail states.
- Skip/Hint/Quit invariant untouched (lesson screens not modified).
- Correctness model: AI examiner = answer-key grading; LLM phrases feedback only.
- Secure storage stays DB-key-only; locale in shared_preferences.

## After copying, run
```
flutter pub get
flutter gen-l10n
flutter analyze
flutter test
```

## Open follow-ups (not in this handoff)
1. l10n: new strings are hardcoded BN for design parity — move to
   `lib/l10n/app_{en,bn,ja}.arb` (add navHome/navProgress/home* keys).
2. PitchScreen entry point (card inside Speak tab).
3. T-108: real `retentionByDay()` + per-skill accuracy queries in `srs_local.dart`.
4. dueCountProvider reading `SrsLocal.dueCards()` for the pink card.

## Suggested commit message
```
design: v4 "Bold Ink" UI refresh (theme, 4-tab shell, home, onboarding, progress+AI check)

- new token set: ink-black surfaces + yellow/pink/blue/green accent inks
- 4-tab shell (Home/Learn/Speak/Progress); Kana/Write/Pitch/Review as pushes
- new HomeScreen, OnboardingScreen (language-first), ProgressScreenV4 + AiCheckScreen
- fonts: Baloo Da 2 / Zen Kaku Gothic New / Archivo
- spec-checked: D-001 neutral framing, answer-key grading, Skip/Hint/Quit intact

Design source: Home v4.dc.html (Claude design project)
```
